function elegirDados(){

    let numDadosJ1 = document.getElementById("selecionJugador1").value;
    let numDadosJ2 = document.getElementById("dadosJugador2").value;
    let resultados1Contenedor = document.getElementById("dadosJ1");
    let resultados2Contenedor = document.getElementById("dadosJ2");

    let dadosJ1 = document.getElementsByClassName(dado);
    let dadosJ2 = document.getElementsByClassName(dado);

    for (let index = 0; index < numDadosJ1; index++) {
        crearDadoJ1();
    }
}

function crearDadoJ1(){
    let numDadosJ1 = document.getElementsByClassName(dadosJugador1);
    let nuevoDadoJ1 = document.createElement("img");
    nuevoDadoJ1.className = "dado";
    let nuevoNumero = numDadosJ1 + 1;
    nuevoDado.setAttribute("id", dadoJI+nuevoNumero);
    document.getElementById("dadosJ1").appendChild(nuevoDadoJ1);
}


